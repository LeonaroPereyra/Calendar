package com.calendar.calendar

import android.os.Bundle
import android.support.design.widget.Snackbar
import android.support.v7.app.AppCompatActivity
import androidx.navigation.ui.AppBarConfiguration
import com.calendar.calendar.databinding.ActivitySaveUserBinding

class ActivityUserUpload : AppCompatActivity() {
    private lateinit var appBarConfiguration: AppBarConfiguration
    private lateinit var binding: ActivitySaveUserBinding
}